import React from "react";
import JobCard from "./JobCard";
import JobPortalSearchBox from "./SearchBox";
import BlueGradianBox from "./BlueGradianBox";
import Box from "@mui/material/Box";
import Navbar from "./NavBar";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
  card: {
    margin: "10px",
    padding: "10px",
    display: "flex",
    flexDirection: "row",
    flexWrap: "wrap"
  }
});

function CategorizedJobs() {

  const classes = useStyles();
  
  const searchData = JSON.parse(localStorage.getItem("searchData"));
  console.log(searchData);
  const arr = JSON.parse(localStorage.getItem("formData"));

  return (
    <>
      <Navbar />
      <BlueGradianBox />
      <JobPortalSearchBox />
      <Box className={classes.card}>
        {arr?.map((element) => (
          <JobCard jobTitle={element.jobTitle} companyName={element.companyName} jobDescription={element.jobDescription} />
        ))}
      </Box>
    </>
  );
}

export default CategorizedJobs;
